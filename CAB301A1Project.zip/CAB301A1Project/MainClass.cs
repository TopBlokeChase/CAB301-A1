﻿using System;

namespace CAB301_A1_Solution
{
    internal class MainClass
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Main has run correctly");
        }
    }
}
